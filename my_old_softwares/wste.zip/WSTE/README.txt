﻿Read Me First Before Using  https://shimo.im/doc/CNjmpgF7ercLZEik

Hello , welcome to use "Walkedby's Steam Text Editor".
Before using it ,you have read these contents below.
If you don't agree with it, please do not use this software.
If you use this software , that means you have understood and accepted these contents below.

1.This software only help you writing text in Steam format. This software has nothing to do with Steam or Valve Corporation. Anything you done with this software which made something bad has nothing to do with this software or Gordon Walkedby.
2.You should learn how to use software correctly first, any strange or uncorrect behave you done which made something bad has nothing to do with this software or Gordon Walkedby.
3.You must know ,due to my technically problem, the preview in the software is only for refenrence,might not as well as they look like in steam.
4.This software is no longer supported, no update will be available since Dec,30th,2017.
5.This software is licensed under a Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License. That means you can share the whole and unmodified program to others , and you must write the name of "Gordon Walkedby", and you can't use this software for commercial purposes.If you remix, transform, or build upon the program, you can't release or distribute the modified program.
6.This software has no virus codes and it can't break your computer or network.But if you get this software from a way which is not recommended by Gordon Walkedby, this is not promised.
7.When you use this software , it will collect some infomations with Baidu and some other tools in order to count how many people use it and where the people are. Gordon Walkedby will not use these infomations in unlegal. But I don't promise Baidu and some other tools will use these infomations in unlegal.
8.When you use this software, you might have to login steam account, Gordon Walkedby will not collect your steam infomation, all infomation are saved in your own PC.

Dec,30th,2017.

使用前必讀 https://shimo.im/doc/QdKVcn2nuXcjJkyT

你好，歡迎使用“走過去的 Steam 文本編輯器”。
在使用它之前，你必須閱讀以下內容。
如果你不同意以下內容，請不要使用該軟體。
如果你使用了該軟體，即視為你理解並同意以下內容。

1.本軟體只負責幫助編寫 Steam 文本格式 下的文本，與 Steam 或者 Valve Corporation 沒有任何直接關連。任何你在 Steam 或者其他網站發佈的任何內容所造成的不良後果與本軟體或者戈登走過去無關。
2.你在使用本軟體時應該學會如何正確使用本軟體，任何不恰當的操作導致的不良後果與本軟體或者戈登走過去無關。
3.由於能力有限，軟體內的預覽效果僅供參考，實際請以 Steam 軟體內的實際效果為準。
4.本軟體已經停止更新，包括其他的附帶的 BUG 維修服務等。
5.本軟體使用 姓名標示-非商業性-禁止改作 4.0 國際 (CC BY-NC-ND 4.0) 協議授權，意味著你可以分發本軟體的完整的安裝文件（包括主程序和附加文件夾），但是你必須註明戈登走過去的名字，並且不得將本素材進行商業目的之使用，若你重混、轉換本軟體，或依本軟體建立新軟體或者其他內容，則你不得散布改作後的軟體或者其他內容。
6.本軟體並不包含任何的病毒程序或者會對計算機和網絡產生破壞的代碼，但是如果你從非戈登走過去指定的來源獲得本軟體，該保證無效。
7.本軟體在使用時會在後台使用百度統計等進行數據收集，用途是為了統計用戶的數量和大致地理位置，戈登走過去不會洩漏或者非法利用這些數據。但是不保證百度等數據收集者不會非法利用或者洩漏這些數據。
8.本軟體在使用過程中可能會要求你登錄 Steam 帳戶，戈登走過去不會收集你們的任何 Steam 帳戶信息，所有信息會保存在你的 Windows 設備內。

2017年12月30日
